import React, {ChangeEvent, KeyboardEvent, useState} from 'react';
import {FilterValuesType} from './App';
import c from './Todolist.module.css'


type TaskType = {
    id: string
    title: string
    isDone: boolean
}

type PropsType = {
    title: string
    tasks: Array<TaskType>
    removeTask: (taskId: string) => void
    changeFilter: (value: FilterValuesType) => void
    addTask: (title: string) => void
    changeStatus: (currentId: string, value: boolean) => void
    filter: FilterValuesType
}

export function Todolist({filter, ...props}: PropsType) {

    let [title, setTitle] = useState("")
    const [error, setError] = useState(true)


    const addTask = () => {
        if (title.trim()) {
            props.addTask(title.trim());
            setTitle("");
            setError(true)
        }
    }

    const onChangeHandler = (e: ChangeEvent<HTMLInputElement>) => {
        setTitle(e.currentTarget.value)
        setError(false)
    }

    const onKeyPressHandler = (e: KeyboardEvent<HTMLInputElement>) => {
        if (e.charCode === 13) {
            addTask();

        }
    }

    const onAllClickHandler = () => props.changeFilter("all");
    const onActiveClickHandler = () => props.changeFilter("active");
    const onCompletedClickHandler = () => props.changeFilter("completed");


    const onChangeHandlerForChangeStatus = (event: ChangeEvent<HTMLInputElement>, currentId: string) => {
        props.changeStatus(currentId, event.currentTarget.checked)

    }

    return <div>
        <h3>{props.title}</h3>
        <div>
            <input className={error ? c.error : ''} value={title}
                   onChange={onChangeHandler}
                   onKeyPress={onKeyPressHandler}
            />
            <button onClick={addTask}>+</button>
            {error && <div className={c.errorMessage}> Title is required</div>}
        </div>
        <ul>
            {
                props.tasks.map(t => {
                    const onClickHandler = () => props.removeTask(t.id)
                    /* const onChangeHandlerForChangeStatus = (event: ChangeEvent<HTMLInputElement>) => {
                         props.changeStatus(t.id, event.currentTarget.checked)
                     }*/


                    return <li key={t.id} >
                        <input type="checkbox" checked={t.isDone}
                               onChange={(event) => onChangeHandlerForChangeStatus(event, t.id)}/>
                        <span className={t.isDone ? c.isDone : ''}>{t.title}</span>
                        <button onClick={onClickHandler}>x</button>
                    </li>
                })
            }
        </ul>
        <div>
            <button className={filter === 'all' ? c.activeFilter : ''} onClick={onAllClickHandler}>All</button>
            <button className={filter === 'active' ? c.activeFilter : ''} onClick={onActiveClickHandler}>Active</button>
            <button className={filter === 'completed' ? c.activeFilter : ''}
                    onClick={onCompletedClickHandler}>Completed
            </button>
        </div>
    </div>
}
