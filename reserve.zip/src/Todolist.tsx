import React from "react";
import {FilterValuesType} from "./App";


export type inPropsType = {
    id: number
    title: string
    isDone: boolean
}
type propsType = {
    title: string
    tasks: Array<inPropsType>
    removeTasks: (id: number) => void;
    changeFilter: (value: FilterValuesType) => void;

}


export const Todolist = (props: propsType) => {
    return (

        <div>
            <h3>{props.title}</h3>
            <div>
                <input/>
                <button>+</button>
            </div>
            <ul>

                {
                    props.tasks.map((t) => {
                        return <li>
                            <button onClick={()=> {props.removeTasks(t.id)}}>X</button>
                            <input type="checkbox" checked={t.isDone}/> <span>{t.title}</span></li>
                    })
                }
                {/*<li><input type="checkbox" checked={props.tasks[0].isDone}/> <span>{props.tasks[0].title}</span></li>*/}
            </ul>
            <div>
                <button onClick={() => {props.changeFilter('all')}}>All</button>
                <button onClick={() => {props.changeFilter('active')}}>Active</button>
                <button onClick={() => {props.changeFilter('completed')}}>Completed</button>
            </div>

        </div>
    )
}
