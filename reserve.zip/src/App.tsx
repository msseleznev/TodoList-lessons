import React, {useState} from 'react';
import './App.css';
import {inPropsType, Todolist} from "./Todolist";
export type FilterValuesType = 'all' | 'active'| 'completed'

function App() {

    let [tasks, setTasks] = useState<Array<inPropsType>>([
        {id: 1, title: "Hello world1111111", isDone: true},
        {id: 2, title: "I am Happy11111111", isDone: false},
        {id: 3, title: "Yo1111111111", isDone: false}
    ])  //применяем хук useState для изменения исходного массива на отфильрованный массив

    let [filter, setFilter] = useState<FilterValuesType>()
    function removeTasks(id: number) {

        let filteredTasks = tasks.filter(t => t.id !== id)
        setTasks(filteredTasks)
    }
    function changeFilter(value: FilterValuesType) {
        setFilter(value)
    }
    let tasksForTodolist = tasks;
    if (filter === 'active') {
        tasksForTodolist = tasks.filter(t=>t.isDone === false)
    }
    if (filter === 'completed') {
        tasksForTodolist = tasks.filter(t=>t.isDone === true)
    }


    return (
        <div className="App">
            <Todolist title={"What to learn111111"}
                      tasks={tasksForTodolist}
                      removeTasks={removeTasks}
                      changeFilter= {changeFilter}

            />
        </div>
    );
}

export default App;
